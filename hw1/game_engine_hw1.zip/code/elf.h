#pragma once

class elf {
public:
	void draw(unsigned programID);
	int dir = 0; //0��  1�k  2�e  3��
	float angleY = 0;
private:
};
